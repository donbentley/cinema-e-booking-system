package com.csci4050.termproject.cinema_e_booking;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CinemaEBookingApplicationTests {

	@Test
	void contextLoads() {
	}

}
