package com.csci4050.termproject.cinema_e_booking;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CinemaEBookingApplication {

	public static void main(String[] args) {
		SpringApplication.run(CinemaEBookingApplication.class, args);
	}

}
