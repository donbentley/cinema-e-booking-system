package com.cinemaebooking.cinema_e_booking_api_mongodb;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CinemaEBookingApiMongodbApplication {

	public static void main(String[] args) {
		SpringApplication.run(CinemaEBookingApiMongodbApplication.class, args);
	}

}
