package com.cinemaebooking.cinema_e_booking_api_mongodb;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CinemaEBookingApiMongodbApplicationTests {

	@Test
	void contextLoads() {
	}

}
